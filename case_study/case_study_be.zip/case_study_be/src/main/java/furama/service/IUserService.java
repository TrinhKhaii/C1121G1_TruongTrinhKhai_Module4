package furama.service;
/*
    Created by Trinh Khai
    Date: 22/04/2022
    Time: 09:29
*/

import furama.model.user_role_entity.User;

import java.util.Optional;

public interface IUserService extends IGeneralService<User> {
}
