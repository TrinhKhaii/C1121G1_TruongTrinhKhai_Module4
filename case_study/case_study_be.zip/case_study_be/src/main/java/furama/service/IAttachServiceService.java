package furama.service;
/*
    Created by Trinh Khai
    Date: 23/04/2022
    Time: 21:11
*/

import furama.model.contract_entity.AttachService;

public interface IAttachServiceService extends IGeneralService<AttachService> {
}
